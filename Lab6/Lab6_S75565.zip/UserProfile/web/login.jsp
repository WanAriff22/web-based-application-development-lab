<%-- 
    Document   : login
    Created on : 12 May 2026, 3:17:48 pm
    Author     : ASUS
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
    </head>
    <body>
        <h1>Login System</h1>
        <%
            String error = request.getParameter("error");
            if (error != null) {
        %>
        <p class="error">Invalid username or password..!</p>
        <%    
            }
        %>
        <form action="doLogin.jsp" method="post">
            <table>
                <tr>
                    <td>Username</td>
                    <td>
                        <input type="text" name="username" required>
                    </td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td>
                        <input type="password" name="password" required>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Login">
                        <input type="reset" value="Cancel">
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>
