<%-- 
    Document   : processUser
    Created on : 12 May 2026, 3:16:11 pm
    Author     : ASUS
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Process User</title>
    </head>
    <body>
        <h1>User Registration Result</h1>
        <%
            Connection conn = null;
            PreparedStatement ps = null;
            try {
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                String firstname = request.getParameter("firstname");
                String lastname = request.getParameter("lastname");
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/cse3023","root","");
                String sql = "INSERT INTO userprofile " + "VALUES(?,?,?,?)";
                ps = conn.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, password);
                ps.setString(3, firstname);
                ps.setString(4, lastname);
                int row = ps.executeUpdate();
                if (row > 0) {
                    out.println("<h3>" + "User registered " + "successfully!" + "</h3>");
                    out.println("<a href='login.jsp'>"+ "Go Login" + "</a>");
                }
            } catch (Exception e) {
                out.println(
                        "Error: " + e
                );
            }
        %>
    </body>
</html>
