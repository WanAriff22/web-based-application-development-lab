<%-- 
    Document   : doLogin
    Created on : 12 May 2026, 3:18:41 pm
    Author     : ASUS
--%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <%
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            try {
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3307/cse3023", "root", "");
                String sql = "SELECT * FROM "
                        + "userprofile " + "WHERE username collate utf8mb4_bin =? " + "AND password collate utf8mb4_bin =?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, password);
                rs = ps.executeQuery();
                if (rs.next()) {
                    String firstname = rs.getString("firstname");
                    String lastname = rs.getString("lastname");
                    response.sendRedirect("main.jsp?" + "username=" 
                            + username+ "&firstname="+ firstname+ "&lastname=" + lastname);
                } else {
                    response.sendRedirect("login.jsp?error=1");
                }
            } catch (Exception e) {
                out.println(e);
            }
        %>
    </body>
</html>
