<%-- 
    Document   : main
    Created on : 12 May 2026, 3:19:29 pm
    Author     : ASUS
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Main Page</title>
    </head>
    <body>
        <h1>Welcome to Main Page</h1>
        <h3>Username:<%= request.getParameter("username")%></h3>
        <h3>First Name:<%= request.getParameter("firstname")%></h3>
        <h3>Last Name:<%= request.getParameter("lastname")%></h3>
    </body>
</html>
